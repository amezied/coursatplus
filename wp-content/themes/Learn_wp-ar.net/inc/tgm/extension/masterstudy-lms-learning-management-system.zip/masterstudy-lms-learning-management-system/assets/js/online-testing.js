(function($){
    $(document).ready(function(){
        $('body').addClass('stm-online-testing');
    });
})(jQuery);