<?php function stm_configurations_share()
{ ?>
    <div class="stm_share">
        <label>Share:</label>
        <span class='st_facebook_large' displayText=''></span>
        <span class='st_twitter_large' displayText=''></span>
        <span class='st_googleplus_large' displayText=''></span>
        <script type="text/javascript">var switchTo5x = true;</script>
        <script type="text/javascript" src="https://ws.sharethis.com/button/buttons.js"></script>
        <script type="text/javascript">stLight.options({
                doNotHash: false,
                doNotCopy: false,
                hashAddressBar: false
            });</script>
    </div>

<?php } ?>